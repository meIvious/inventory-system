package InventorySystem;

public interface Comparable<T> {

	int compareTo(Order other);

	
}
